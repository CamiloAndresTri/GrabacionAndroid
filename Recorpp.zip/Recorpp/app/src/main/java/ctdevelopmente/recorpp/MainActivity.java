package ctdevelopmente.recorpp;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.os.Bundle;
import android.os.Environment;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {

    // Llamar a las clases mediaPlayer, y Media Recorder e  importar paquetes

    private MediaPlayer mediaPlayer;
    private MediaRecorder recorder;

    // Generar el string privado OUTPUT_FILE para guardar los datos

    private String OUTPUT_FILE;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        // Asignar una ruta de guardado del archivo (Tarjeta SD) y su nombre.

        OUTPUT_FILE= Environment.getExternalStorageDirectory()+"/grabacionhardcore.3gpp";
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void buttonTapped(View view){

        // Inicio de la acción (Pulsar). Depurador para confirmar que boton se pulsa

        switch(view.getId()) {

            // Prueba del boton Record

            case R.id.Record:
                try{

                    // Iniciar metodo grabar

                    beginRecording();
                } catch (Exception e){
                    e.printStackTrace();
                }break;

            // Prueba del boton Stop Recording

            case R.id.Stop_R:
                try{

                    // Detener metodo grabar

                    stopRecording();
                } catch (Exception e){
                    e.printStackTrace();
                }break;

            // Prueba del boton Play

            case R.id.Play:
                try{

                    // Iniciar metodo reproducir

                    playRecording();
                } catch (Exception e){
                    e.printStackTrace();
                }break;

            // Prueba del boton Stop

            case R.id.Stop_P:
                try{

                    // Detener metodo reproducir

                    stopPlayback();
                } catch (Exception e){
                    e.printStackTrace();
                }break;
        }
    }
    private void beginRecording() throws IOException {
        ditchMediaRacorder();

        // Lugar de almacenamiento del audio grabado

        File outFile = new File(OUTPUT_FILE);

        // Eliminar archivos con el mismo nombre

        if(outFile.exists())
            outFile.delete();


        // Nuevo objeto de grabacion

        recorder = new MediaRecorder();

        // Fuente de audio (Microfono)

        recorder.setAudioSource(MediaRecorder.AudioSource.MIC);

        // Seleccionar Formato de salida (no hay wav)

        recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);

        // Seleccionar Formato de codificacion (Advanced Audio Codification)

        recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);

        // Configurar salida de audio

        recorder.setOutputFile(OUTPUT_FILE);

        // Preparar grabacion

        recorder.prepare();

        // Iniciar grabacion

        recorder.start();
    }
    private void ditchMediaRacorder(){

        // Asegurarse de que exista un medio para grabar

        if(recorder != null)
            recorder.release();
    }
    private void stopRecording() {

        // Desactivar la grabadora

        if(recorder!=null)
            recorder.stop();
    }
    private void playRecording() throws Exception{

        ditchMediaPlayer();

        // Iniciar nuevo reproductor de audio

        mediaPlayer= new MediaPlayer();

        // Configurar fuente de datos a reproducir

        mediaPlayer.setDataSource(OUTPUT_FILE);

        // Preparar el reproductor

        mediaPlayer.prepare();

        // Iniciar el reproductor

        mediaPlayer.start();

    }

    private void ditchMediaPlayer() {

        // Comprobar que exista el reproductor

        if (mediaPlayer!=null)
        {
            try{
                mediaPlayer.release();
            }catch(Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void stopPlayback() {

        //  Desactivar el reproductor de audio

        if (mediaPlayer!=null)
                mediaPlayer.stop();

    }


}
